<?php 
include 'conn.php';
$id=$_GET['id'];
$del=mysqli_query($con,"DELETE FROM orders WHERE oid='$id'");
if ($del) {
	header('location:dorders.php');
}
 ?>