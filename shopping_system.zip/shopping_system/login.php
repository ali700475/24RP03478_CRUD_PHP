<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Signup</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #ecf0f1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .signup-box {
            width: 350px;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .signup-box h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50;
        }

        .signup-box label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            color: #2c3e50;
        }

        .signup-box input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #bdc3c7;
            border-radius: 4px;
        }

        .signup-box button {
            width: 100%;
            padding: 10px;
            background: #1abc9c;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
        }

        .signup-box button:hover {
            background: #16a085;
        }
        a{
            text-decoration: none;
            color: white;
        }
    </style>
</head>
<body>

<div class="signup-box">
    <h2>Login Here</h2>
    
    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" placeholder="Username" required>

        <label>Password</label>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="sub"> Login</button><br><br>
        <button><a href="signup.php">Signup Here!!</a> </button>
    </form>
</div>
</body>
</html>
<?php 
include 'conn.php';
session_start();
if (isset($_POST['sub'])) {
    $u=$_POST['username'];
    $p=$_POST['password'];
    $ins=mysqli_query($con,"SELECT * FROM users WHERE username='$u' AND password='$p'");
    if ($ins->num_rows>0) {
        $_SESSION['users']=$u;
        setcookie("user1", $u, time() + 60, "/");
        header('location:home.php');
    }
    else{
        echo "<script>alert('Invalid Username or Password')</script>";
    }
}

 ?>