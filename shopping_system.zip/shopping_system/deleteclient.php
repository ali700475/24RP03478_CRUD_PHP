<?php 
include 'conn.php';
$id=$_GET['id'];
$del=mysqli_query($con,"DELETE FROM clients WHERE cid='$id'");
if ($del) {
	header('location:dclients.php');
}
 ?>